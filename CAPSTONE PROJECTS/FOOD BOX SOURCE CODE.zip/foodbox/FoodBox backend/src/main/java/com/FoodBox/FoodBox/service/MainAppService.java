package com.FoodBox.FoodBox.service;

public class MainAppService {

}
