import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-food',
  templateUrl: './remove-food.component.html',
  styleUrls: ['./remove-food.component.css']
})
export class RemoveFoodComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
