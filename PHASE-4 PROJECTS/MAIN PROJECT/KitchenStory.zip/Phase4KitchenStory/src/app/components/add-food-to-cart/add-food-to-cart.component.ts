import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-food-to-cart',
  templateUrl: './add-food-to-cart.component.html',
  styleUrls: ['./add-food-to-cart.component.css']
})
export class AddFoodToCartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
